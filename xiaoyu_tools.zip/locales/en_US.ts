const en_US = {
  welcome: 'Welcome to',
  xiaoyu_tools: `xiaoyu's tools!`
};
export { en_US };
