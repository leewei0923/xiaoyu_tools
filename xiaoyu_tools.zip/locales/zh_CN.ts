/*
 * @Author: leewei
 * @Date: 2022-07-10 16:10:45
 * @LastEditors: leewei
 * @LastEditTime: 2022-07-12 15:46:35
 * @FilePath: \xiaoyu_tools\locales\zh_CN.ts
 * @Description: 
 * 
 * Copyright (c) 2022 by leewei, All Rights Reserved. 
 */
const zh_CN = {
  welcome: "欢迎来到",
  xiaoyu_tools: "小鱼工具箱"
  // photoControl back
  
};
export {
    zh_CN
}   
