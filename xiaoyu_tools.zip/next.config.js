/** @type {import('next').NextConfig} */


const nextConfig = {
  basePath: '/xiaoyu_tools',
  reactStrictMode: true
};

module.exports = nextConfig;
