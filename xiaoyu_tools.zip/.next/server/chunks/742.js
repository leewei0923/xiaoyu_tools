"use strict";
exports.id = 742;
exports.ids = [742];
exports.modules = {

/***/ 702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ useAppSelector),
/* harmony export */   "T": () => (/* binding */ useAppDispatch)
/* harmony export */ });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);
/*
 * @Author: leewei
 * @Date: 2022-07-08 16:08:44
 * @LastEditors: leewei
 * @LastEditTime: 2022-07-08 22:12:53
 * @FilePath: \xiaoyu_tools\src\redux\hooks.ts
 * @Description: 
 * 
 * Copyright (c) 2022 by leewei, All Rights Reserved. 
 */ 
const useAppDispatch = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_0__.useDispatch)()
;
const useAppSelector = react_redux__WEBPACK_IMPORTED_MODULE_0__.useSelector;


/***/ }),

/***/ 531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pu": () => (/* binding */ selectTheme),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "es": () => (/* binding */ onChangeMode)
/* harmony export */ });
/* unused harmony export themeSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/*
 * @Author: leewei
 * @Date: 2022-07-08 17:05:18
 * @LastEditors: leewei
 * @LastEditTime: 2022-07-08 22:36:10
 * @FilePath: \xiaoyu_tools\src\redux\theme\themeSlice.ts
 * @Description: 主题切片
 *
 * Copyright (c) 2022 by leewei, All Rights Reserved.
 */ 
const initialThemeState = "light";
const themeSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "theme",
    initialState: initialThemeState,
    reducers: {
        onChangeMode: (state, action)=>{
            return action.payload || "light";
        }
    }
});
const { onChangeMode  } = themeSlice.actions;
const selectTheme = (state)=>{
    return state.themeMode;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (themeSlice);


/***/ }),

/***/ 7618:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * theme: 简单封装处理浏览器存储LocalStorage
 * author: leewei
 * time: 2022.06.07
 */ class HandleStorage {
    prefix = "xiaoyu";
    isSupport() {
        if (window.localStorage === undefined || window.localStorage === null || localStorage === undefined || localStorage === null) {
            return false;
        }
        return true;
    }
    setStorage(key, value) {
        // 判断是否支持localStorage
        if (!this.isSupport()) {
            throw new Error("\u4E0D\u652F\u6301localStorage");
        }
        window.localStorage.setItem(`${this.prefix}_${key}`, value);
    }
    getStorage(key) {
        if (!this.isSupport()) {
            throw new Error("\u4E0D\u652F\u6301localStorage");
        }
        if (!window.localStorage.getItem(`${this.prefix}_${key}`)) {
            return "";
        }
        const content = window.localStorage.getItem(`${this.prefix}_${key}`) || "";
        return content;
    }
    // 删除传入的key
    removeKey() {}
    // 清空Stoage
    clearStorage() {}
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HandleStorage);


/***/ })

};
;