exports.id = 873;
exports.ids = [873];
exports.modules = {

/***/ 9844:
/***/ ((module) => {

// Exports
module.exports = {
	"dark": "footer_dark__fJsd3",
	"container": "footer_container__kgCYE",
	"link": "footer_link___dy5W",
	"statement": "footer_statement__0u_mF",
	"beian": "footer_beian__U_OaK",
	"otherLinks": "footer_otherLinks__O_Xd2",
	"linkName": "footer_linkName__aeziT",
	"logo": "footer_logo__DvjDN",
	"logoName": "footer_logoName__JJueK"
};


/***/ }),

/***/ 3306:
/***/ ((module) => {

// Exports
module.exports = {
	"dark": "header_dark__JG6ge",
	"container": "header_container__9qPdE",
	"logo": "header_logo__ycR_7",
	"switchThemeBtn": "header_switchThemeBtn__JDkX8",
	"linkBox": "header_linkBox___ipvp"
};


/***/ }),

/***/ 5048:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _src_redux_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(702);
/* harmony import */ var _src_redux_theme_themeSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(531);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _footer_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9844);
/* harmony import */ var _footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_footer_module_scss__WEBPACK_IMPORTED_MODULE_6__);







const linkData = [
    {
        id: "1",
        name: "Home",
        url: "/"
    },
    {
        id: "2",
        name: "Github",
        url: "https://github.com/leewei0923"
    }, 
];
function Footer() {
    /**
   * 公共部分
   */ const themeState = (0,_src_redux_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useAppSelector */ .C)(_src_redux_theme_themeSlice__WEBPACK_IMPORTED_MODULE_4__/* .selectTheme */ .Pu);
    /**
   * desc: 用于 classnames 处理类名
   */ const container = classnames__WEBPACK_IMPORTED_MODULE_5___default()({
        [(_footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default().container)]: true,
        [(_footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default().dark)]: themeState !== "light"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: container,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default().link),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default().otherLinks),
                        children: linkData.map((item)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: item.url,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: (_footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default().linkName),
                                    children: item.name
                                })
                            }, item.id + item.name);
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default().logo),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/xiaoyu_tools/logo.png",
                                alt: "xiaoyu Logo",
                                width: 40,
                                height: 40
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default().logoName),
                                children: "Xiaoyu's Tools"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: (_footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default().statement),
                children: "\xa92022, content by Leewei. All Rights Reserved. The Website by leewei."
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: (_footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default().beian),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: "https://beian.miit.gov.cn",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: (_footer_module_scss__WEBPACK_IMPORTED_MODULE_6___default().a),
                        children: "\u7696ICP\u590720004665\u53F7-2"
                    })
                })
            })
        ]
    });
};


/***/ }),

/***/ 9586:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header_Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/static_data/links.ts
/**
 * theme: gradient_color_palette 链接数据
 * author: leewei
 * time: 2022.06.07
 */ const gradientLinks = [
    {
        id: "1",
        url: "https://github.com/leewei0923",
        text: "Github"
    },
    {
        id: "2",
        url: "/usage",
        text: "Usage"
    }
];

// EXTERNAL MODULE: ./src/redux/hooks.ts
var hooks = __webpack_require__(702);
// EXTERNAL MODULE: ./src/redux/theme/themeSlice.ts
var themeSlice = __webpack_require__(531);
// EXTERNAL MODULE: ./src/utils/HandleStorage.ts
var HandleStorage = __webpack_require__(7618);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./src/components/Header/header.module.scss
var header_module = __webpack_require__(3306);
var header_module_default = /*#__PURE__*/__webpack_require__.n(header_module);
// EXTERNAL MODULE: external "@arco-design/web-react/icon"
var icon_ = __webpack_require__(2396);
;// CONCATENATED MODULE: ./src/components/Header/Header.tsx










const Header = (props)=>{
    /**
   *
   * desc: 全局公共部分
   */ const { siteName  } = props;
    const themeState = (0,hooks/* useAppSelector */.C)(themeSlice/* selectTheme */.Pu);
    const dispatch = (0,hooks/* useAppDispatch */.T)();
    const handleStorage = new HandleStorage/* default */.Z();
    /**
   * @description: 改变主题的模式 'light' : 'dark'
   * @param {*} void
   * @return {*}
   */ const onChangeThemeMode = ()=>{
        dispatch((0,themeSlice/* onChangeMode */.es)(themeState === "light" ? "dark" : "light"));
        handleStorage.setStorage("theme", themeState === "light" ? "dark" : "light");
    };
    const initRender = ()=>{
        const theme = handleStorage.getStorage("theme");
        if (theme !== "light") {
            handleStorage.setStorage("theme", "dark");
            dispatch((0,themeSlice/* onChangeMode */.es)("dark"));
        }
    };
    (0,external_react_.useEffect)(()=>{
        initRender();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const container = external_classnames_default()({
        [(header_module_default()).container]: true,
        [(header_module_default()).dark]: themeState !== "light"
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: container,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (header_module_default()).logo,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "bx bx-palette"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: siteName
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (header_module_default()).linkBox,
                children: gradientLinks.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: item.url,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: item.text
                            })
                        })
                    }, item.id + item.text)
                )
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (header_module_default()).switchThemeBtn,
                onClick: ()=>onChangeThemeMode()
                ,
                children: themeState === "light" ? /*#__PURE__*/ jsx_runtime_.jsx(icon_.IconSunFill, {
                    style: {
                        fontSize: "25px",
                        color: "black"
                    }
                }) : /*#__PURE__*/ jsx_runtime_.jsx(icon_.IconMoonFill, {
                    style: {
                        fontSize: "25px",
                        color: "white"
                    }
                })
            })
        ]
    });
};
/* harmony default export */ const Header_Header = (Header);


/***/ })

};
;