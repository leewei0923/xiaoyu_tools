(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4800:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
// EXTERNAL MODULE: ./src/redux/theme/themeSlice.ts
var themeSlice = __webpack_require__(531);
;// CONCATENATED MODULE: ./src/redux/store.ts
/*
 * @Author: leewei
 * @Date: 2022-07-08 16:08:57
 * @LastEditors: leewei
 * @LastEditTime: 2022-07-08 22:12:30
 * @FilePath: \xiaoyu_tools\src\redux\store.ts
 * @Description: 
 * 
 * Copyright (c) 2022 by leewei, All Rights Reserved. 
 */ 

const store = (0,toolkit_.configureStore)({
    reducer: {
        themeMode: themeSlice/* default.reducer */.ZP.reducer
    }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__(3126);
;// CONCATENATED MODULE: ./locales/zh_CN.ts
/*
 * @Author: leewei
 * @Date: 2022-07-10 16:10:45
 * @LastEditors: leewei
 * @LastEditTime: 2022-07-12 15:46:35
 * @FilePath: \xiaoyu_tools\locales\zh_CN.ts
 * @Description: 
 * 
 * Copyright (c) 2022 by leewei, All Rights Reserved. 
 */ const zh_CN = {
    welcome: "\u6B22\u8FCE\u6765\u5230",
    xiaoyu_tools: "\u5C0F\u9C7C\u5DE5\u5177\u7BB1"
};


;// CONCATENATED MODULE: ./locales/en_US.ts
const en_US = {
    welcome: "Welcome to",
    xiaoyu_tools: `xiaoyu's tools!`
};


;// CONCATENATED MODULE: ./locales/index.ts
/*
 * @Author: leewei
 * @Date: 2022-07-12 15:46:18
 * @LastEditors: leewei
 * @LastEditTime: 2022-07-12 16:30:13
 * @FilePath: \xiaoyu_tools\locales\index.ts
 * @Description: 
 * 
 * Copyright (c) 2022 by leewei, All Rights Reserved. 
 */ 

function loadLocale(lang) {
    let locale = null;
    let message = null;
    switch(lang){
        case "en-US":
            locale = "en-US";
            message = en_US;
            break;
        case "zh-CN":
            locale = "zh-CN";
            message = zh_CN;
            break;
        default:
            locale = "en-US";
            message = en_US;
            break;
    }
    return {
        locale,
        message
    };
}


// EXTERNAL MODULE: ./node_modules/@arco-design/web-react/dist/css/arco.css
var arco = __webpack_require__(4342);
;// CONCATENATED MODULE: ./pages/_app.tsx








function MyApp({ Component , pageProps  }) {
    const { 0: lang , 1: setLang  } = (0,external_react_.useState)("zh-CN");
    const { locale , message  } = loadLocale(lang);
    (0,external_react_.useEffect)(()=>{
        if (lang !== window.navigator.language) {
            setLang(window.navigator.language);
        }
    }, [
        lang
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
        store: store,
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_intl_.IntlProvider, {
            locale: locale,
            messages: message,
            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pu": () => (/* binding */ selectTheme),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "es": () => (/* binding */ onChangeMode)
/* harmony export */ });
/* unused harmony export themeSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/*
 * @Author: leewei
 * @Date: 2022-07-08 17:05:18
 * @LastEditors: leewei
 * @LastEditTime: 2022-07-08 22:36:10
 * @FilePath: \xiaoyu_tools\src\redux\theme\themeSlice.ts
 * @Description: 主题切片
 *
 * Copyright (c) 2022 by leewei, All Rights Reserved.
 */ 
const initialThemeState = "light";
const themeSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "theme",
    initialState: initialThemeState,
    reducers: {
        onChangeMode: (state, action)=>{
            return action.payload || "light";
        }
    }
});
const { onChangeMode  } = themeSlice.actions;
const selectTheme = (state)=>{
    return state.themeMode;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (themeSlice);


/***/ }),

/***/ 4342:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 3126:
/***/ ((module) => {

"use strict";
module.exports = require("react-intl");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4800));
module.exports = __webpack_exports__;

})();